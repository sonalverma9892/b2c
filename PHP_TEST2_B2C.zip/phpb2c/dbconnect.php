
<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
  $con = mysql_connect('localhost','root','verma909') or die(mysql_error());
  mysql_select_db('B2C') or die("cannot select DB");
?>
