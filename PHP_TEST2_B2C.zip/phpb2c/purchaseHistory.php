<?php include("header.php");
	include("dbconnect.php");
  // session_start();
  header("Cache-Control: no cache");
  session_cache_limiter("private_no_expire");
  // $con = mysql_connect('localhost','root','') or die(mysql_error());
  // mysql_select_db('B2C') or die("cannot select DB");
// echo "Session User: " .$_SESSION['userfullname'];
  ?>

    <!-- Navigation -->
    <?php
    // session_start();
    if (isset($_SESSION['sess_user'])): ?>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="margin-top:0%">
        <div class="container">
          <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  My Account
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
                  <a class="dropdown-item" href="support.php">Contact Support</a>
                  <a class="dropdown-item" href="logout.php">Logout</a>
                </div>
              </li>
              <li class="nav-item">
                <a href="cart.php">
                <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
                <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <?php else: ?>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
          <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="login.php" >Login</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="register.php">Register</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="support.php">Contact Support</a>
              </li>
              <li class="nav-item">
                <a href="cart.php">
                <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
                <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <?php endif; ?>
    <?php
      if(isset($_SESSION['sess_user'])){
        $user = $_SESSION['sess_user'];
      }
    ?>
    <div class="container">
    <div class="h2 nav-link">Order History</div>

    <?php
      $sql = mysql_query("SELECT Transactions.DateTime, Orders.code, Orders.quantity, Orders.price FROM Orders INNER JOIN Transactions ON Orders.Transaction_id = Transactions.Transaction_id WHERE Email = '$user'");
      $history = array();

      // look through query
      if(mysql_num_rows($sql) > 0){
        while($row = mysql_fetch_assoc($sql)){
          // add each row returned into an array
          $history[] = $row;
        }
        // print_r($history);
    ?>

    <table class="table table-striped" style="align:center">
    <tbody>
    <tr style="background-color:#5DADE2  ">
    <th style="text-align:center;"><strong>Date and Time</strong></th>
    <th style="text-align:center"><strong>Product Code</strong></th>
    <th style="text-align:center"><strong>Quantity</strong></th>
    <th style="text-align:center"><strong>Price</strong></th>
    </tr>
    <?php
        foreach ($history as $key => $value){
    ?>
    				<tr>
    				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><strong><?php echo $history[$key]["DateTime"]; ?></strong></td>
    				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo $history[$key]["code"]; ?></td>
    				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo $history[$key]["quantity"]?></td>
    				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo "$" .$history[$key]["price"]?></td>
    <?php
    		}
    ?>
    </tbody>
    </table>

    <?php
      }else{
    ?>
    <div class="alert alert-warning" role="alert">
      You currently have no orders to display
    </div>

    <?php
      }
    ?>
    </div>
    <footer class="py-4 bg-dark" style="margin-top:25%">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Business To Consumer 2018</p>
      </div>
      <!-- /.container -->
    </footer>
<?php include("footer.php");?>
