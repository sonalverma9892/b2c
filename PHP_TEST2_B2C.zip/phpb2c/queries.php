<!-- to get all transactions of user hhaving email ="" -->

<!-- SELECT Transactions.Transaction_id, Transactions.DateTime, Orders.code, Orders.quantity, Orders.price FROM Orders
INNER JOIN Transactions ON Orders.Transaction_id = Transactions.Transaction_id WHERE email='vermasonal909@gmail.com' -->
