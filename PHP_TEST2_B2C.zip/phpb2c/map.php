<?php include("header.php");
	include("dbconnect.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
  // session_start();
  header("Cache-Control: no cache");
  session_cache_limiter("private_no_expire");
  // $con = mysql_connect('localhost','root','') or die(mysql_error());
  // mysql_select_db('B2C') or die("cannot select DB");
  // $user = $_SESSION['sess_user'];

  if (isset($_SESSION['sess_user'])): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                My Account
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
                <a class="dropdown-item" href="support.php">Contact Support</a>
                <a class="dropdown-item" href="logout.php">Logout</a>
              </div>
            </li>
            <li class="nav-item">
              <a href="cart.php">
              <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
              <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <?php else: ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="support.php">Contact Support</a>
            </li>
            <li class="nav-item">
              <a href="cart.php">
              <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
              <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <?php endif;

  $result= array();
  $sql = "SELECT * FROM markers";
  $stmt = mysql_query($sql);
  while($row=mysql_fetch_assoc($stmt)){
     $result[] = $row;
 }

 foreach ($result as $key)
  $locations[]=array('id'=>$key['id'], 'name'=>$key['name'], 'address'=> $key['address'], 'lat'=> $key['lat'], 'lng'=> $key['lng']);
  $markers = json_encode( $locations );
  // print_r($markers);
?>

<script>
  var labels = ["1", "2", "3", "4", "5", " "];
   var labelIndex = 0;

  <?php
    echo "var markers=$markers;\n";
  ?>

  function initMap() {
    var latlng = new google.maps.LatLng( 43.70011, -79.4163); // default location
    var myOptions = {
      zoom: 8,
      center: latlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      mapTypeControl: true
    };

    var map = new google.maps.Map(document.getElementById('mapall'),myOptions);
    var infowindow = new google.maps.InfoWindow(), marker, lat, lng;
    var json=markers;

		for( var i in json ){
			id =(json[i].id);
			lat = (json[i].lat);
			console.log(lat);
			lng = (json[i].lng);
			name = (json[i].name);
			address = (json[i].address);

			marker = new google.maps.Marker({
				position: new google.maps.LatLng(lat,lng),
				label: {text:labels[labelIndex++ % labels.length], color: "white", fontWeight: "bold", fontSize: "16px"},
				id:id,
				name:name,
				address:address,
				map: map
			});

			var myPin2 = new google.maps.MarkerImage('images/mypin2.png');
			if(marker.id == 6){
			 marker.setIcon(myPin2);
			}
			google.maps.event.addListener( marker, 'click', function(e){
				infowindow.setContent(this.name + "<br/>"+this.address );
				infowindow.open( map, this );
			}.bind( marker ) );
		}

    if (navigator.geolocation) {
      console.log('Geolocation is supported!');
      navigator.geolocation.getCurrentPosition(function(position){
			json['5'].lat = position.coords.latitude;
			json['5'].lng = position.coords.longitude;

      console.log(json);


      });
			// infoWindow.setPosition(currentLocation);
    }
    else {
      console.log('Geolocation is not supported for this Browser/OS.');
    }
    console.log(json);
  }
</script>
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBYyG2ldpjk8gyt9jU419QKbzh80C3-1Ks&callback=initMap">
</script>

<div class="container">
  <div class="h2" style="text-align:center;">Please select your nearest store</div></br>
	<div class="row">
		<div class="col-md-5">
      <div id="mapall" style="width:1000px;height:450px; margin-left:15%; margin-bottom:10%;"></div>
      <form method="post">
        <?php
          if (!empty($result)) {
            $count = count($result);
            foreach($result as $key=>$value){
              if (--$count <= 0) {
              break;
              }
              ?>
              <input style="margin-left:40%; font-weight:bold;" type="radio"  name="id" value="<?php echo $result[$key]["id"];?>" onclick="this.form.submit()"
                <?php
                  if(isset($_POST["id"]) && ($_POST['id'] == $result[$key]["id"]))
                  {
                    $_SESSION["id"] = $result[$key]["id"];
                    $_SESSION["storeName"] = $result[$key]["name"];
                    $_SESSION["storeAddress"] = $result[$key]["address"];
                    echo "checked";}else{echo " ";}
                ?> >
                <?php echo $result[$key]["id"];?>.
              <span style="margin-left:5%; font-weight:bold;">
                <input name="name" type="hidden"
                  <?php
                    if(isset($_POST["name"]) && ($_POST['name'] == $result[$key]["name"])){
                      $_SESSION["strName"] = $result[$key]["name"];
                       echo "hiiih";}
                  ?>><?php echo $result[$key]["name"]; ?></span>
              <div style="margin-left:52%; margin-bottom:10%"><input name="address" type="hidden"><?php echo $result[$key]["address"]; ?></div>
              <?php
            }
          }
        ?>
      </form>
    </div>
  </div>

<?php
  if(isset($_POST['id']) && (isset($_SESSION["id"])))
  {
    // echo $_SESSION["id"];
    // echo $_SESSION["storeName"];
    // echo $_SESSION["storeAddress"];

    if(isset($_SESSION['sess_user'])) { ?>
      <button class="btn btn-primary" style="margin-right: 10%; margin-left:16%; padding: 10px 150px;" onclick="Javascript:window.location.href ='unregisteredUser.php';">Continue</button>
  <?php
      }else{
    ?>
      <button class="btn btn-primary" style="margin-right: 10%; margin-left:16%; padding: 10px 150px;" onclick="Javascript:window.location.href ='checkout.php';">Continue</button>
    <?php
  }
 }
?>
</div>
<?php include("footer.php"); ?>
