<html>
<head>
    <title>B2C Canada</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/shop-homepage.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,300,600,700' rel='stylesheet' type='text/css'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
  <?php
    $item_total = 0;
    $currency = '&#36;';
    $shipping_cost      = 5.50;
    $taxes              = 3;

    $total = 0;
    $b = 0;

    $resultset = array();
    if(isset($_SESSION['sess_user'])){
      $user = $_SESSION['sess_user'];
      $query = mysql_query("SELECT * FROM User WHERE Email='$user'");

      while($row=mysql_fetch_assoc($query)) {
        $resultset[] = $row;
      }

      $sql = mysql_query("SELECT SUM(Orders.price) FROM Orders INNER JOIN Transactions ON Orders.Transaction_id = Transactions.Transaction_id WHERE Email = '$user'");
      while($row=mysql_fetch_assoc($sql)) {
        $result[] = $row;
      }
      
      $discount = $result[0]["SUM(Orders.price)"]/100;

    }else{
      $user = $_SESSION['email'];
    }
  ?>

  <style type="text/css">
    .invoice-title h2{
        display: inline-block;
    }
    .table > tbody > tr > .thick-line{
        border-top: 2px solid;
    }
    .table > thead > tr > .thick-line{
        border-bottom: 2px solid;
    }
    .table > tbody > tr > .thick-line {
        border-top: 2px solid;
    }
  </style>
  <div class='container'>
    <div class='row'>
      <div class='col-xs-12'>
        <div class='invoice-title'>
          <h2>Invoice</h2>
        </div>
        <hr>
        <div class='row'>
          <div class='col-xs-6'>
            <address>
              <strong>Billed To:</strong><br>
              <p>
                <div>
                  <?php
                    if(isset($_SESSION['sess_user'])) {
                      echo $resultset[0]['FullName']. "<br>";
                      echo $resultset[0]['Street']. ", " .$resultset[0]["Address"]. "<br>";
                      echo $resultset[0]['City']. ", " .$resultset[0]['State']. "<br>";
                      echo $resultset[0]['PostalCode'];
                    }else{
                      echo $_SESSION['fullnameUnregisteredUser']. "<br>";
                      echo $_SESSION['streerUnregisteredUser']. ", " .$_SESSION['addressUnregisteredUser']. "<br>";
                      echo $_SESSION['cityUnregisteredUser']. ", " .$_SESSION['stateUnregisteredUser']. "<br>";
                      echo $_SESSION['postalCodeUnregisteredUser'];
                    }
                  ?>
                </p>
              </address>
            </div>
          </div></br>
          <div class='row'>
            <div class='col-xs-6'>
              <address>
                <strong>Payment Method:</strong><br>
                <?php
                  echo $type .'<br>';
                  if(isset($_POST['register'])){
                    echo $email;
                  }else{
                    echo $user;
                  }
                ?>
              </address>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class='row'>
      <div class='col-md-12'>
        <div class='panel panel-default'>
          <div class='panel-heading'>
            <h3 class='panel-title'><strong>Order summary</strong></h3>
          </div>
          <!-- <div class='panel-body'>
            <div class='table-responsive'> -->
              <table class='table table-bordered'>
                <tbody>
                  <tr>
                    <th class='text-center'><strong>Item</strong></th>
                    <th class='text-center'><strong>Code</strong></th>
                    <th class='text-center'><strong>Quantity</strong></th>
                    <th class='text-center'><strong>Price</strong></th>
                  </tr>
                  <?php
                    foreach($_SESSION["cart_item"] as $item){
                  ?>
                  <tr>
                    <td style='text-align:center;border-bottom:#F0F0F0 1px solid;'><strong><?php echo $item['name']; ?></strong></td>
                    <td style='text-align:center;border-bottom:#F0F0F0 1px solid;'><?php echo $item['code']; ?></td>
                    <td style='text-align:center;border-bottom:#F0F0F0 1px solid;'><?php echo $item['quantity']; ?></td>
                    <td style='text-align:center;border-bottom:#F0F0F0 1px solid;'> $ <?php echo $item['price']*$item['quantity']; ?></td>
                  </tr>
                  <?php
                    $item_total += ($item['price']*$item['quantity']);
                    }
                    $maxDiscount = (15*$item_total)/100;
                    $grand_total = $item_total + $shipping_cost;
                    $tax_amount  = round($item_total * ($taxes / 100));
                    $grand_total = $grand_total + $tax_amount;
                    $list_tax = 'HST : '. $currency. sprintf("%01.2f", $tax_amount).'<br />';
                    $shipping_cost = ($shipping_cost)?'B2C Shipping : '.$currency. sprintf("%01.2f", $shipping_cost).'<br />':'';
                  ?>
                  <tr>
                    <td colspan="5" align=right><strong>Subtotal:</strong> <?php echo "$".$item_total; ?></td>
                  </tr>
                  <?php
                    if(isset($_SESSION["sess_user"])){
                      if($discount <= $maxDiscount){
                        $list_discount = 'Discount : '. $currency. sprintf("%01.2f", $discount).'<br />';
                      }else{
                        $discount = 0;
                        $list_discount = 'Discount : '. $currency. sprintf("%01.2f", $discount).'<br />';
                      }
                      $final_total = $grand_total - $discount;
                      $list_total = 'Grand Total : '. $currency. sprintf("%01.2f", $final_total).'<br />';
                    }
                  ?>
                  <tr>
                    <td colspan="5" align=right><span style="float:right;text-align: right; "><?php echo $shipping_cost. $list_tax; ?>Estimated Total : <?php echo $currency. sprintf("%01.2f", $grand_total).'<br />'; if(isset($_SESSION["sess_user"])){ echo $list_discount.'<br />'.$list_total;}?></span></td>
                  </tr>
                </tbody>
              </table>
            <!-- </div>
          </div> -->
        </div>
      </div>
    </div>

<?php include("footer.php"); ?>
