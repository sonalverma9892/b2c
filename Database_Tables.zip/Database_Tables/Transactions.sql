-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 12, 2018 at 11:33 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `B2C`
--

-- --------------------------------------------------------

--
-- Table structure for table `Transactions`
--

CREATE TABLE `Transactions` (
  `Transaction_id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `DateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Transactions`
--

INSERT INTO `Transactions` (`Transaction_id`, `Email`, `DateTime`) VALUES
(8, 'vermasonal909@gmail.com', '2018-07-02 22:26:58'),
(10, 'xyz@gmail.com', '2018-07-02 22:43:33'),
(12, 'vermasonal909@gmail.com', '2018-07-03 01:40:28'),
(23, 'ankur_gcet@yahoo.co.in', '2018-07-05 01:37:07'),
(24, 'ankur_gcet@yahoo.co.in', '2018-07-05 01:40:57'),
(25, 'vermasonal909@gmail.com', '2018-07-05 05:02:06'),
(26, 'vermasonal909@gmail.com', '2018-07-05 05:22:51'),
(27, 'ankur_gcet@yahoo.co.in', '2018-07-05 05:36:36'),
(28, 'vermasonal909@gmail.com', '2018-07-05 05:44:09'),
(29, 'vermasonal909@gmail.com', '2018-07-08 21:54:30'),
(45, 'ankur_gcet@yahoo.co.in', '2018-07-09 01:22:23'),
(46, 'ankur_gcet@yahoo.co.in', '2018-07-09 01:34:00'),
(48, 'ankur_gcet@yahoo.co.in', '2018-07-09 01:43:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Transactions`
--
ALTER TABLE `Transactions`
  ADD PRIMARY KEY (`Transaction_id`),
  ADD KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Transactions`
--
ALTER TABLE `Transactions`
  MODIFY `Transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
