-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 12, 2018 at 11:33 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `B2C`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `product_id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`product_id`, `name`, `code`, `image`, `price`) VALUES
(1, 'Futon Sofa Bed', 'PRDT101', 'images/product1.jpeg', 449.99),
(2, 'Chair', 'PRDT102', 'images/product3.jpeg', 224.99),
(3, 'Dinning Table', 'PRDT103', 'images/product4.jpeg', 375.99),
(4, 'Study Table', 'PRDT104', 'images/product5.jpeg', 175.99),
(5, 'Dressing Table', 'PRDT105', 'images/product6.jpg', 399.00),
(6, 'Sofa', 'PRDT106', 'images/product2.jpeg', 799.99),
(7, 'Crockery Unit', 'PRDT107', 'images/croceryunit.jpeg', 299.99),
(8, 'TV stand', 'PRDT108', 'images/TV.jpeg', 199.99),
(9, 'Bed side Table', 'PRDT109', 'images/bedsideTable.jpeg', 149.99),
(10, 'Dinining Table', 'PRDT110', 'images/dininingtable.png', 599.98),
(11, 'Coffee Table', 'PRDT111', 'images/coffeetable.jpeg', 149.98),
(12, 'Extending Dining Table', 'PRDT112', 'images/extendingdiningtable.jpeg', 359.99),
(13, 'Shelf', 'PRDT113', 'images/shelf.jpg', 99.98),
(14, 'Convertible Chair', 'PRDT114', 'images/convertiblechair.jpeg', 699.98),
(15, 'Leather sofa bed', 'PRDT115', 'images/leathersofabed.jpeg', 999.98);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
