-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 09, 2018 at 11:17 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `B2C`
--
CREATE DATABASE IF NOT EXISTS `B2C` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `B2C`;

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE `markers` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`id`, `name`, `address`, `lat`, `lng`) VALUES
(1, 'B2C Store#1', '3800 Rutherford Rd, Woodbridge, ON', 43.807659, -79.536461),
(2, 'B2C Store#2', '125 Cross Ave unit 1, Oakville, ON', 43.442547, -79.706787),
(3, 'B2C Store#3', '1725 Kingston Road, Pickering, ON', 43.848270, -79.072029),
(4, 'B2C Store#4', '4040 Creditview Rd, Mississauga, ON', 43.596905, -79.640282),
(5, 'B2C Store#5', '8990 Chinguacousy Rd, Brampton, ON', 43.705341, -79.696861),
(6, 'Current Location', '', 0.000000, 0.000000);

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

CREATE TABLE `Orders` (
  `OrderID` int(11) NOT NULL,
  `Transaction_id` int(11) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`OrderID`, `Transaction_id`, `code`, `quantity`, `price`) VALUES
(5, 8, 'PRDT102', '3', '674.97'),
(6, 8, 'PRDT105', '1', '399'),
(9, 10, 'PRDT101', '3', '1349.97'),
(10, 10, 'PRDT107', '4', '1199.96'),
(27, 23, 'PRDT108', '1', '199.99'),
(28, 23, 'PRDT103', '1', '375.99'),
(29, 24, 'PRDT108', '2', '399.98'),
(30, 24, 'PRDT101', '1', '449.99'),
(31, 25, 'PRDT104', '1', '175.99'),
(32, 26, 'PRDT105', '2', '798'),
(33, 27, 'PRDT104', '1', '175.99'),
(34, 27, 'PRDT105', '1', '399'),
(35, 28, 'PRDT108', '1', '199.99'),
(36, 29, 'PRDT114', '2', '1399.96'),
(48, 45, 'PRDT111', '1', '149.98'),
(49, 45, 'PRDT112', '2', '719.98'),
(50, 45, 'PRDT115', '3', '2999.94'),
(51, 46, 'PRDT105', '1', '399'),
(53, 48, 'PRDT110', '1', '599.98');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `product_id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`product_id`, `name`, `code`, `image`, `price`) VALUES
(1, 'Futon Sofa Bed', 'PRDT101', 'images/product1.jpeg', 449.99),
(2, 'Chair', 'PRDT102', 'images/product3.jpeg', 224.99),
(3, 'Dinning Table', 'PRDT103', 'images/product4.jpeg', 375.99),
(4, 'Study Table', 'PRDT104', 'images/product5.jpeg', 175.99),
(5, 'Dressing Table', 'PRDT105', 'images/product6.jpg', 399.00),
(6, 'Sofa', 'PRDT106', 'images/product2.jpeg', 799.99),
(7, 'Crockery Unit', 'PRDT107', 'images/croceryunit.jpeg', 299.99),
(8, 'TV stand', 'PRDT108', 'images/TV.jpeg', 199.99),
(9, 'Bed side Table', 'PRDT109', 'images/bedsideTable.jpeg', 149.99),
(10, 'Dinining Table', 'PRDT110', 'images/dininingtable.png', 599.98),
(11, 'Coffee Table', 'PRDT111', 'images/coffeetable.jpeg', 149.98),
(12, 'Extending Dining Table', 'PRDT112', 'images/extendingdiningtable.jpeg', 359.99),
(13, 'Shelf', 'PRDT113', 'images/shelf.jpg', 99.98),
(14, 'Convertible Chair', 'PRDT114', 'images/convertiblechair.jpeg', 699.98),
(15, 'Leather sofa bed', 'PRDT115', 'images/leathersofabed.jpeg', 999.98);

-- --------------------------------------------------------

--
-- Table structure for table `Transactions`
--

CREATE TABLE `Transactions` (
  `Transaction_id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `DateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Transactions`
--

INSERT INTO `Transactions` (`Transaction_id`, `Email`, `DateTime`) VALUES
(8, 'vermasonal909@gmail.com', '2018-07-02 22:26:58'),
(10, 'xyz@gmail.com', '2018-07-02 22:43:33'),
(12, 'vermasonal909@gmail.com', '2018-07-03 01:40:28'),
(23, 'ankur_gcet@yahoo.co.in', '2018-07-05 01:37:07'),
(24, 'ankur_gcet@yahoo.co.in', '2018-07-05 01:40:57'),
(25, 'vermasonal909@gmail.com', '2018-07-05 05:02:06'),
(26, 'vermasonal909@gmail.com', '2018-07-05 05:22:51'),
(27, 'ankur_gcet@yahoo.co.in', '2018-07-05 05:36:36'),
(28, 'vermasonal909@gmail.com', '2018-07-05 05:44:09'),
(29, 'vermasonal909@gmail.com', '2018-07-08 21:54:30'),
(45, 'ankur_gcet@yahoo.co.in', '2018-07-09 01:22:23'),
(46, 'ankur_gcet@yahoo.co.in', '2018-07-09 01:34:00'),
(48, 'ankur_gcet@yahoo.co.in', '2018-07-09 01:43:42');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `User_id` int(11) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `DOB` date NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Street` varchar(10) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `City` varchar(20) NOT NULL,
  `State` varchar(15) NOT NULL,
  `PostalCode` varchar(10) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`User_id`, `FullName`, `Email`, `Phone`, `DOB`, `Gender`, `Street`, `Address`, `City`, `State`, `PostalCode`, `Password`) VALUES
(5, 'Ankur Macwan', 'ankur_gcet@yahoo.co.in', '6477058810', '1986-06-08', 'Male', '49', 'Silverstone Drive', 'Etobicoke', 'Ontario', 'M9V 4B1', 'e104c000ba2bf871deada58d00203f70'),
(3, 'Lizza Parmar', 'lizza@gmail.com', '6477742880', '1992-11-23', 'Female', '2344', 'Dufferin Street', 'York', 'Ontario', 'M6E 3S4', 'd945597c9526b3d96518872d41df735e'),
(1, 'Sonal Verma', 'vermasonal909@gmail.com', '6477742880', '1992-11-09', 'Female', '555', 'Brimorton Drive', 'Scarborough', 'Ontario', 'M1H 2G', '40d0984083a127ba2864ea438914211a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Orders`
--
ALTER TABLE `Orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `code` (`code`),
  ADD KEY `Transaction_id` (`Transaction_id`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `Transactions`
--
ALTER TABLE `Transactions`
  ADD PRIMARY KEY (`Transaction_id`),
  ADD KEY `Email` (`Email`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`Email`),
  ADD KEY `User_id` (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `Orders`
--
ALTER TABLE `Orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `Transactions`
--
ALTER TABLE `Transactions`
  MODIFY `Transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Orders`
--
ALTER TABLE `Orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`code`) REFERENCES `tblproduct` (`code`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`Transaction_id`) REFERENCES `Transactions` (`Transaction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
