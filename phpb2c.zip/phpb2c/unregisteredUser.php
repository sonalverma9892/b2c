<?php include("header.php");
	include("dbconnect.php");
  // session_start();

  header("Cache-Control: no cache");
  session_cache_limiter("private_no_expire");
  // connect to the database
  // $con = mysql_connect('localhost','root','') or die(mysql_error());
  // mysql_select_db('B2C') or die("cannot select DB");
  error_reporting(E_ALL & ~E_NOTICE);
  if (isset($_SESSION['sess_user'])): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                My Account
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
                <a class="dropdown-item" href="logout.php">Logout</a>
              </div>
            </li>
            <li class="nav-item">
              <a href="cart.php">
              <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
              <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <?php else: ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="support.php">Contact Support</a>
            </li>
            <li class="nav-item">
              <a href="cart.php">
              <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
              <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>


  <?php endif;

  if(isset($_POST["next"])){
    $_SESSION["email"] = $_POST["email"];
    echo $_SESSION["email"];

  }


  $storeName = $_SESSION["storeName"];
  $storeAddress = $_SESSION["storeAddress"];


  if (isset($_POST["register"]) || isset($_SESSION['sess_user'])) {
		// initializing variables
		$errors = array();



    if(isset($_SESSION['sess_user'])){
      $resultset = array();
      $user = $_SESSION['sess_user'];

      $query = mysql_query("SELECT * FROM User WHERE Email='$user'");
  		// $result = mysql_num_rows($query);
      while($row=mysql_fetch_assoc($query)) {
        $resultset[] = $row;
      }

      $sql = mysql_query("SELECT SUM(Orders.price) FROM Orders INNER JOIN Transactions ON Orders.Transaction_id = Transactions.Transaction_id WHERE Email = '$user'");
      while($row=mysql_fetch_assoc($sql)) {
        $result[] = $row;
      }
      // echo $result[0]["SUM(Orders.price)"];
      $discount = $result[0]["SUM(Orders.price)"]/100;
      // echo $discount;
    }else if(isset($_POST["register"])){
      $email = $_SESSION["email"];

  	  // receive all input values from the form
  	  $fullname = $_POST['fullname'];
      $_SESSION['fullnameUnregisteredUser'] = $fullname;
  		$street = $_POST['street'];
      $_SESSION['streerUnregisteredUser'] = $street;
  		$address = $_POST['address'];
      $_SESSION['addressUnregisteredUser'] = $address;
  		$city = $_POST['city'];
      $_SESSION['cityUnregisteredUser'] = $city;
  		$state = $_POST['state'];
      $_SESSION['stateUnregisteredUser'] = $state;
  		$postalcode = $_POST['postalcode'];
      $_SESSION['postalCodeUnregisteredUser'] = $postalcode;

    }
    $item_total = 0;
		$currency = '&#36;';
		$shipping_cost      = 5.50; //shipping cost
		$taxes              = 3;

		$total = 0; //set initial total value
		$b = 0; //var for
    ?>

    <div class="card border-dark mb-3 mx-auto" style="max-width: 37rem;">
    <!-- <div class="col-md-5 mx-auto"> -->
      <div class="card-header" style="font-size:26px; font-weight:bold; text-align:center;">Your shipping details</div>
      <div class="card-body text-dark">
      <div class="card-title" style="font-size:22px; font-weight:bold"><u>Email Address</u></div>
      <div class="card-text" style="font-size:20px; margin-bottom:5%"><?php if(isset($_POST["register"])){echo $email;}else{echo $user;} ?></div>
      <div class="card-title" style="font-size:22px; font-weight:bold"><u>Shipping Address</u></div>
      <div class="card-text" style="font-size:20px"><?php if(isset($_POST["register"])){ echo $fullname;}else{ echo $resultset[0]["FullName"];} ?></div>
      <div class="card-text" style="font-size:20px"><?php if(isset($_POST["register"])){ echo $street. ", " .$address;}else{ echo $resultset[0]["Street"]. ", ".$resultset[0]["Address"];} ?></div>
      <div class="card-text" style="font-size:20px"><?php if(isset($_POST["register"])){ echo $city. ", " .$state;}else{ echo $resultset[0]["City"]. ", " .$resultset[0]["State"];} ?></div>
      <div class="card-text" style="font-size:20px; margin-bottom:5%"><?php if(isset($_POST["register"])){ echo $postalcode;}else{ echo $resultset[0]["PostalCode"];} ?></div>
      <div class="card-title" style="font-size:22px; font-weight:bold"><u>Store Selected</u></div>
      <div class="card-text" style="font-size:20px"><?php echo $storeName ?></div>
      <div class="card-text" style="font-size:20px;"><?php echo $storeAddress ?></div>
      <!-- <div  style="margin-bottom:5%"><a href="map.php">Edit store Address</a></div> -->

      <div class="card-title" style="font-size:22px; font-weight:bold"><u>Order Detail</u></div>
      <table class="table table-sm" style="align:center">
      <tbody>
      <tr>
      <th style="text-align:center;"><strong>Name</strong></th>
      <th style="text-align:center"><strong>Code</strong></th>
      <th style="text-align:center"><strong>Quantity</strong></th>
      <th style="text-align:center"><strong>Price</strong></th>
      </tr>
      <?php
      foreach ($_SESSION["cart_item"] as $item){

      ?>
          <tr>
          <td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><strong><?php echo $item["name"]; ?></strong></td>
          <td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo $item["code"]; ?></td>
          <!-- <input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" /> -->
          <td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><input disabled type="number" size="2" min="1" max="50" maxlength="2" name="cartQuantity" value="<?php echo $item["quantity"]?>" />
          <td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo "$".$item["price"]*$item["quantity"]; ?></td>
          <!-- <td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><a  href="cart.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction">Remove Item</a></td> -->
          </tr>
          <?php
          $item_total += ($item["price"]*$item["quantity"]);
          // $total = ($total + $item_total);
      }
      $maxDiscount = (15*$item_total)/100;
      // echo "max discount : " .$maxDiscount;
      $grand_total = $item_total + $shipping_cost; //grand total including shipping cost
  		// echo "grand " .$grand_total;
  		//list and calculate all taxes in array
  		$tax_amount     = round($item_total * ($taxes / 100));
  		$grand_total    = $grand_total + $tax_amount;  //add tax val to grand total



  		// echo "grand " .$grand_total;
  		// print_r($tax_item);
  		$list_tax = 'HST : '. $currency. sprintf("%01.2f", $tax_amount).'<br />';

  		$shipping_cost = ($shipping_cost)?'B2C Shipping : '.$currency. sprintf("%01.2f", $shipping_cost).'<br />':'';
  		?>

  <tr>
  <td colspan="5" align=right><strong>Subtotal:</strong> <?php echo "$".$item_total; ?></td></tr>
  <?php
    if(isset($_SESSION["sess_user"])){
      if($discount <= $maxDiscount){
        $list_discount = 'Discount : '. $currency. sprintf("%01.2f", $discount).'<br />';
      }else{
        $discount = 0;
        $list_discount = 'Discount : '. $currency. sprintf("%01.2f", $discount).'<br />';
      }
      $final_total = $grand_total - $discount;
      $list_total = 'Grand Total : '. $currency. sprintf("%01.2f", $final_total).'<br />';
    }
  ?>
  <tr><td colspan="5" align=right><span style="float:right;text-align: right; "><?php echo $shipping_cost. $list_tax; ?>Estimated Total : <?php echo $currency. sprintf("%01.2f", $grand_total).'<br />'; if(isset($_SESSION["sess_user"])){ echo $list_discount.'<br />'.$list_total;}?></span></td></tr>
  <!-- <tr><button type="submit" class="btn btn-primary" name="update">Update</button></td></tr> -->
  </tbody>
  </table>
  <label style="font-size:20px;"><i>*Estimated delivery in 40 minutes after order is placed</i></label><br>
  <button type="button" class="btn btn-primary" style="width:250px; margin-left:27%; margin-right:auto;" data-toggle="modal" data-target="#myModal">Continue</button></br>
    </div>
  </div>

    <div id="myModal" class="modal">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="sendEmail.php" method="post">
            <div class="modal-header">
              <h4 class="modal-title">Payment details</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
              <div class="display-td">
                <img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png">
              </div></br>
              <label style="font-size:20px">Full name (as on card)</label>
              <input required type="text" name="cardName" class="form-control">
              <label style="font-size:20px">Card Number*</label>
              <input required type="text" name="cardNumber" class="form-control">
              <div class="row">
                <div  class="col-sm-6 form-group">
                  <label style="font-size:20px">Expiry*</label>
                  <select required name="expiryMonth" class="form-control">
                    <option value="MM">MM</option>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="03">03</option>
                    <option value="04">04</option>
                    <option value="05">05</option>
                    <option value="06">06</option>
                    <option value="07">07</option>
                    <option value="08">08</option>
                    <option value="09">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                  </select>
                </div>
                <div style="margin-top:5%" class="col-sm-6 form-group">
                  <label style="font-size:20px"></label>
                  <select required name="expiryYear" class="form-control">
                    <option value="YY">YY</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    <option value="24">24</option>
                    <option value="25">25</option>
                    <option value="26">26</option>
                    <option value="27">27</option>
                    <option value="28">28</option>
                  </select>
                </div>
              </div>
              <label style="font-size:20px">Security Code*</label>
              <input required type="number" name="expiry" min="100" max="999" class="form-control" placeholder="CVC"></br>
              <div class="modal-footer">
                <button type="submit" name="apply" class="btn btn-primary" style="width:500px">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

  <?php }else{
      if(!isset($_SESSION['sess_user'])) {?>

    <div class="col-md-5 mx-auto">
      <form action="unregisteredUser.php" method="post">
      <h2 style="text-align:center">Please provide below details for shipping</h2>
        <div class="form-group">
          <input type="text" class="form-control" name="fullname" placeholder="Full Name" required="required">
        </div>

        <div class="form-group">
          <input id="street_number" name="street" placeholder="Street" rows="3" class="form-control" />
        </div>
        <div class="form-group">
          <input id="route" name="address" placeholder="Route" rows="3" class="form-control" />
        </div>

      <div class="form-group">
        <input type="text" id="sublocality_level_1" name="city" placeholder="City" class="form-control">
      </div>

      <div class="row">
        <div class="col-sm-6 form-group">
          <input type="text" id="administrative_area_level_1" name="state" placeholder="State" class="form-control">
        </div>
        <div class="col-sm-6 form-group">
          <input type="text"  id="postal_code" name="postalcode" placeholder="Postal Code" max=6 class="form-control">
        </div>
      </div>

        <div class="form-group">
          <button type="submit" class="btn btn-success btn-lg btn-block" name="register">Done</button>
        </div>
      </form>

      <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCuk2WpGVbhkarHqpDIEi1PSjPXRPW_y08&libraries=places"></script>
      <script type="text/javascript">
      var autocomplete;
      var componentForm = {
      				street_number:'short_name',
              route: 'long_name',
              sublocality_level_1: 'long_name',
      				administrative_area_level_1: 'long_name',
              postal_code: 'short_name'
            };

      function initialize() {
          var input = document.getElementById('street_number');
          var options = {componentRestrictions: {country: 'ca'}};

          autocomplete = new google.maps.places.Autocomplete(input, options);

      		autocomplete.addListener('place_changed', fillInAddress);
      }

      google.maps.event.addDomListener(window, 'load', initialize);

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
      		console.log(addressType);
          if (componentForm[addressType]){
            var val = place.address_components[i][componentForm[addressType]];
              document.getElementById(addressType).value = val;
            }
        }
      }
      </script>
  <?php
  }
}
?>

<?php include("footer.php"); ?>
