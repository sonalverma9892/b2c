<?php include("header.php");
	include("dbconnect.php");
header("Cache-Control: no cache");
session_cache_limiter("private_no_expire");
// session_start();
if (isset($_SESSION['sess_user'])): ?>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
		<div class="container">
			<a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarNavDropdown">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
					</li>
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							My Account
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
							<a class="dropdown-item" href="support.php">Contact Support</a>
							<a class="dropdown-item" href="logout.php">Logout</a>
						</div>
					</li>
					<li class="nav-item">
						<a href="cart.php">
						<img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
						<asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
<?php else: ?>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
		<div class="container">
			<a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="login.php">Login</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="register.php">Register</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="support.php">Contact Support</a>
					</li>
					<li class="nav-item">
						<a href="cart.php">
						<img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
						<asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
<?php endif;?>

<div class="col-md-5 mx-auto">
	<form method="post">
		<h2>Secure Checkout</h2></br>
    <label>*indicates a required field</label></br></br>
    <label style="font-size:18px; font-weight:bold; margin-bottom:10%">Do you have a B2C account?</label></br>
    <input type="radio"  name="no" value="No"<?php echo (isset($_POST['no'])&& ($_POST['no'] == 'No'))?'checked="checked"':''; ?> onclick="this.form.submit();" > No
    <input type="radio" style="margin-left:50%" name="no" value="yes" <?php echo (isset($_POST['no']) && ($_POST['no'] == 'yes'))?'checked="checked"':''; ?>  onclick="this.form.submit();" > Yes<br>
	</form>

  <?php
    if(isset($_POST['no']) && ($_POST['no'] == 'No'))
    {
  ?>
	<form method="post" action="unregisteredUser.php">
  	<label>Please enter your email address to check out as a guest.</label></br>
    <label>Email Address*</label>
    <input required type="email" class="form-control" name="email" placeholder="you@email.com" value="<?php echo isset($_POST["email"])? $_SESSION["email"]= $_POST["email"] : " " ?>"></br>
    <button type="submit" class="btn btn-success btn-lg btn-block" name="next" >Next</button>
	</form>

  <?php
    if(isset($_POST["email"])){
      echo "email";
      $_SESSION["email"]= $_POST["email"];
    }
  }else if(isset($_POST['no']) && ($_POST['no'] == 'yes')){ ?>
		<form method="post" action="checkout.php">
			<label>You’ll be asked for your password</label></br>
			<label>Email Address*</label>
			<input required type="email" class="form-control" name="email" placeholder="you@email.com" ></br>
			<label>Password*</label>
			<input required type="password" class="form-control" name="password"></br>
			<button type="submit" class="btn btn-success btn-lg btn-block" name="registerUsernext">Next</button>
		</form>
	<?php }

	if(isset($_POST["registerUsernext"])){
		if(!empty($_POST['email']) && !empty($_POST['password'])) {
			$user = $_POST['email'];
			$pass = $_POST['password'];
			// echo $user;
			// echo $pass;

			$password = md5($pass);
			// echo $password ."<br>";

			// $con = mysql_connect('localhost','root','') or die(mysql_error());
			// mysql_select_db('B2C') or die("cannot select DB");

			$query = mysql_query("SELECT * FROM User WHERE Email='".$user."' AND Password='".$password."'");
			$numrows = mysql_num_rows($query);
			if($numrows != 0)
			{
					while($row = mysql_fetch_assoc($query))
					{
						$dbusername = $row['Email'];
						$dbpassword = $row['Password'];
						$dbfullname = $row['FullName'];
						echo $dbfullname;
						// echo $dbusername ."<br>";
						// echo $dbpassword ."<br>";
					}

				if(($user == $dbusername && $password == $dbpassword))
				{
					$_SESSION['sess_user'] = $user;
					$_SESSION['userfullname'] = $dbfullname;

					/* Redirect browser */
					header("Location: unregisteredUser.php");
				}else{
					$message = '<span style = "color:red; margin-left:45%; font-weight:bold">Invalid Email or Password!</span>';
					echo $message;
				}

			} else {
				$message = '<span style ="color:red; margin-left:47%; font-weight:bold">Sorry, Not a registered User!</span>';
				echo $message;
			}
		}
	}
?>
</div>
<?php include("footer.php"); ?>
