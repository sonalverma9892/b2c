<?php include("header.php");
	include("dbconnect.php");
	 ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="margin-top:0%">
	<div class="container">
		<a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
	</div>
</nav>

<div class="login-card" style="margin-top:10%">
		    <form action="login.php" method="post">
				<h1>Login</h1><br>
		    	<div class="form-group">
						<input type="email" class="form-control" name="email" placeholder="Email" required="required">
		      </div><br>

					<div class="form-group">
				  	<input type="password" class="form-control" min=4 max=8 name="password" placeholder="Password" required="required">
				  </div><br>

				  <div class="form-group">
		      	<button type="submit" class="btn btn-success btn-lg btn-block" name="login">Login</button>
		      </div>
		    </form>
				<div class="text-center">Not Registered? <a href="register.php">Register Now</a></div>
</div>
<footer class="py-4 bg-dark" style="margin-top:10%">
	<div class="container">
		<p class="m-0 text-center text-white">Copyright &copy; Business To Consumer 2018</p>
	</div>
	<!-- /.container -->
</footer>

		<?php
		if(isset($_POST["login"])){

			if(!empty($_POST['email']) && !empty($_POST['password'])) {
					$user = $_POST['email'];
					$pass = $_POST['password'];
					// echo $user;
					// echo $pass;

					$password = md5($pass);
					// echo $password ."<br>";

					// $con = mysql_connect('localhost','root','') or die(mysql_error());
					// mysql_select_db('B2C') or die("cannot select DB");

					$query = mysql_query("SELECT * FROM User WHERE Email='".$user."' AND Password='".$password."'");
					$numrows = mysql_num_rows($query);
					if($numrows != 0)
					{
							while($row = mysql_fetch_assoc($query))
							{
								$dbusername = $row['Email'];
								$dbpassword = $row['Password'];
								$dbfullname = $row['FullName'];
								echo $dbfullname;
								// echo $dbusername ."<br>";
								// echo $dbpassword ."<br>";
							}

						if(($user == $dbusername && $password == $dbpassword))
						{
							session_start();
							$_SESSION['sess_user'] = $user;
							$_SESSION['userfullname'] = $dbfullname;
							/* Redirect browser */
							header("Location: index.php");
						}else{
							$message = '<span style = "color:red; margin-left:42%; font-weight:bold">Invalid Email or Password!</span>';
							echo $message;
							return false;
						}

					} else {
						$message = '<span style ="color:red; margin-left:43%; font-weight:bold">Invalid Email or Password!</span>';
						echo $message;
						return false;
					}
			}
		}
	?>

<?php include("footer.php"); ?>
