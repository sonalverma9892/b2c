<?php include("header.php");
	include("dbconnect.php");
  // session_start();
  // $con = mysql_connect('localhost','root','') or die(mysql_error());
  // mysql_select_db('B2C') or die("cannot select DB");
  ?>
    <!-- Navigation -->
    <?php
    // session_start();
    if (isset($_SESSION['sess_user'])): ?>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="margin-top:0%">
        <div class="container">
          <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  My Account
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
                  <a class="dropdown-item" href="support.php">Contact Support</a>
                  <a class="dropdown-item" href="logout.php">Logout</a>
                </div>
              </li>
              <li class="nav-item">
                <a href="cart.php">
                <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
                <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <?php else: ?>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
          <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="login.php" >Login</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="register.php">Register</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="support.php">Contact Support</a>
              </li>
              <li class="nav-item">
                <a href="cart.php">
                  <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
                <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>

              </li>
            </ul>
          </div>
        </div>
      </nav>
    <?php endif; ?>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- /.col-lg-3 -->

        <div class="col-lg-12">

          <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
              <div class="carousel-item active">
                <img class="d-block img-fluid" src="images/01.jpg" width="1150px" alt="First slide">
              </div>
              <div class="carousel-item">
                <img class="d-block img-fluid" src="images/slide2.jpg" width="1150px" alt="Second slide">
              </div>
              <div class="carousel-item">
                <img class="d-block img-fluid" src="images/slide3.jpg" width="1150px" alt="Third slide">
              </div>
              <div class="carousel-item">
                <img class="d-block img-fluid" src="images/slide4.png" width="1150px" alt="Fourth slide">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>

          <div class="row">

            <?php
          $resultset = array();
            // $current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
            $result = mysql_query("SELECT * FROM tblproduct ORDER BY product_id ASC");
        		while($row=mysql_fetch_assoc($result)) {
        			$resultset[] = $row;
        		}
//print_r($resultset);
              // $product_array = $db_handle->runQuery("SELECT * FROM tblproduct ORDER BY id ASC");
              if (!empty($resultset)) {
                foreach($resultset as $key=>$value){
              ?>
              <div class="col-lg-4 col-md-6 mb-4">
                <div class="card">
                  <form method="post" action="cart.php">
                  <a href=""><img class="card-img-top" src="<?php echo $resultset[$key]["image"]; ?>"></a>
                  <div class="card-body">
                  <h4 class="card-title"><a href="#"><?php echo $resultset[$key]["name"]; ?></a></h4>
                  <h5><?php echo "$".$resultset[$key]["price"]; ?></h5>
                </div>

                <div class="card-footer">
                  <label style="color:blue; font-weight:bold">Qty</label>
                  <input type="number" name="quantity" min="0" max="50" size="2" step=1 value="0"/>
                  <input type="hidden" name="product_code" value="<?php echo $resultset[$key]["code"]; ?>" />
                  <input type="hidden" name="type" value="add" />
                  <!-- <input type="hidden" name="return_url" value="<?php echo $current_url ?>" /><br> -->
                  <button type="submit" class="btn btn-primary" style="width:310px; font-weight:bold; font-size:20px">Add to cart</button>
                </div>

                  </form>

                </div>
                </div>

              <?php
                  }
              }
              ?>
          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-12 -->

      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->


    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Business To Consumer 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->



  <?php include("footer.php"); ?>
