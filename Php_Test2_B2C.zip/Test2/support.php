<?php include("header.php"); ?>
<?php
// session_start();
if (isset($_SESSION['sess_user'])): ?>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="margin-top:0%">
    <div class="container">
      <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              My Account
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
              <a class="dropdown-item" href="support.php">Contact Support</a>
              <a class="dropdown-item" href="logout.php">Logout</a>
            </div>
          </li>
          <li class="nav-item">
            <a href="cart.php">
            <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
            <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<?php else: ?>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="login.php" >Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="register.php">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="support.php">Contact Support</a>
          </li>
          <li class="nav-item">
            <a href="cart.php">
              <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
            <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>

          </li>
        </ul>
      </div>
    </div>
  </nav>
<?php endif; ?>

<div class="card mb-3">
  <img src="images/support.png">
</div>


<div style="margin-left:25%"><img src="images/email2.png" alt="Card image cap" width="100" ><span style="margin-left:48%;"><img src="images/call.png" alt="Card image cap" width="100"><br></span></div>
<div style="margin-left:26%; font-size:20px; font-weight:bold">Email at </a>
  <span style="margin-left:52%;">Call at</span></div>
<span style="margin-left:19%; font-size:18px;"><a href="mailto:business2consumer.ca@gmail.com?subject=&body="> business2consumer.ca@gmail.com</a></span>
<span style="margin-left:28%; font-size:18px;"><a href="tel:+6477742880">+1 647-774-2880</a></span></br>


<footer class="py-4 bg-dark" style="margin-top:5%">
  <div class="container">
    <p class="m-0 text-center text-white">Copyright &copy; Business To Consumer 2018</p>
  </div>
  <!-- /.container -->
</footer>


<?php include("footer.php"); ?>
