<?php include("header.php");
	include("dbconnect.php");

header("Cache-Control: no cache");
session_cache_limiter("private_no_expire");
// session_start();
// connect to the database
// $con = mysql_connect('localhost','root','') or die(mysql_error());
// mysql_select_db('B2C') or die("cannot select DB");
// error_reporting(E_ALL & ~E_NOTICE);

function updateQuantity(){
  if(isset($_SESSION["cart_item"])){
    $cart_count = $_SESSION["qua"];
  }else{
    $cart_count = 0;
  }
  if (isset($_SESSION['sess_user'])): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                My Account
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
                <a class="dropdown-item" href="support.php">Contact Support</a>
                <a class="dropdown-item" href="logout.php">Logout</a>
              </div>
            </li>
            <li class="nav-item">
              <a href="cart.php">
                <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
                <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
              </li>
            </ul>
          </div>
        </div>
    </nav>
  <?php else: ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="support.php">Contact Support</a>
            </li>
            <li class="nav-item">
              <a href="cart.php">
              <img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
              <asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <?php endif;
}

  updateQuantity();
  if(isset($_POST['apply']) && isset($_SESSION['cart_item'])){

      if(isset($_SESSION['sess_user'])){
        $user = $_SESSION['sess_user'];
        $name = $_SESSION['userfullname'];
      }else{
        $user = $_SESSION['email'];
        $name =$_SESSION['fullnameUnregisteredUser'];
      }

    $number= $_POST['cardNumber'];
    function validatecard($number){
      global $type;

      $cardtype = array(
          "Visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
          "Mastercard" => "/^5[1-5][0-9]{14}$/",
          "Amex"       => "/^3[47][0-9]{13}$/",
          "Discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
      );

      if (preg_match($cardtype['Visa'],$number)){
         $type= "Visa";
        return 'Visa';
      }else if (preg_match($cardtype['Mastercard'],$number)){
         $type= "Mastercard";
         return 'Mastercard';
      }else if (preg_match($cardtype['Amex'],$number)){
         $type= "Amex";
         return 'Amex';
      }else if (preg_match($cardtype['Discover'],$number)){
         $type= "Discover";
         return 'Discover';
      }else{
        return false;
      }
    }
    validatecard($number);
    if (validatecard($number) !== false ){
      if((($_POST['expiryYear'] != "YY") || ($_POST['expiryMonth'] != "MM"))){ ?>
        <div class="alert alert-success" style="text-align:center">
          <strong><?php echo $type ?> Detected.</strong> Payment Successfully Done!
        </div>
        <?php
        require('PHPMailer/src/PHPMailer.php');
        require("PHPMailer/src/SMTP.php");
        require("PHPMailer/src/Exception.php");
        $mail = new PHPMailer\PHPMailer\PHPMailer();
        $mail->CharSet =  "utf-8";
        $mail->IsSMTP();

        // $mail->SMTPDebug = 1;
        // enable SMTP authentication
        $mail->SMTPAuth = true;
        // GMAIL username
        $mail->Username = "business2consumer.ca@gmail.com";
        // GMAIL password
        $mail->Password = "B2c12345";
        $mail->SMTPSecure = "ssl";
        // sets GMAIL as the SMTP server
        $mail->Host = "smtp.gmail.com";
        // set the SMTP port for the GMAIL server
        $mail->Port = "465";
        $mail->From='business2consumer.ca@gmail.com';
        $mail->FromName='B2C B2C';
        // echo $user;
        $mail->AddAddress($user, $name);
        $mail->Subject  =  'B2C Invoice';
        $mail->IsHTML(true);
        ob_start();
        require('emailTemplate.php');
        $html = ob_get_clean();
        $mail->MsgHTML($html);


        if($mail->Send()){?>
          <div class="alert alert-success" style="text-align:center">
            <strong>Your receipt is sent to your email</strong>
          </div>
        <?php
          $today = date("Y/m/d H:i:s a");
          $query = "INSERT INTO Transactions (Email, DateTime) VALUES ('$user', '$today')";
          if(mysql_query($query)){
            // echo "Records inserted successfully.";
          } else{
            echo "ERROR: Could not able to execute $query. " . mysql_error($con);
          }

          $getTransId = mysql_insert_id();
          // echo $getTransId;

          foreach ($_SESSION["cart_item"] as $item) {
            $totalPrice = $item['quantity']*$item['price'];
            $sql = "INSERT INTO Orders (Transaction_id, code, quantity, price) VALUES ('$getTransId','$item[code]', '$item[quantity]', '$totalPrice')";
            if(mysql_query($sql)){
              // echo "Records inserted successfully.";
            } else{
              echo "ERROR: Could not able to execute $sql. " . mysql_error($con);
            }
          }

          $mail->Body = "<div class='alert alert-success'>Dear, " .$name. "<br><br> Thank you for shopping with <strong>B2C.</strong> Your order will arrive in 40 minutes.<br> Visit our contact support for any query or feedback</div>";
          $mail->Send();
          // session_destroy();
          unset($_SESSION["cart_item"]);
      		$_SESSION["qua"] = 0;
          updateQuantity();
        }else
        {
          //If emails fails
        }
      }else{ ?>
            <div class="alert alert-Danger" style="text-align:center">
              <strong>Sorry!</strong> You forgot to select your cards expiry details!
            </div>
        <?php }
  }else{  ?>
      <div class="alert alert-danger" class="alert alert-success" style="text-align:center">
        <strong>Sorry!</strong> Invalid Card Number. Please try again!
      </div>
    <?php  }
  } else { ?>
    <div class="alert alert-warning" style="text-align:center">
      <strong>Your order is already placed</strong>
    </div>
<?php
  }
?>

<?php include("footer.php");?>
