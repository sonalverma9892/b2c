<?php include("header.php");
	include("dbconnect.php");?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="margin-top:0%">
	<div class="container">
		<a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
	</div>
</nav>
<div class="register-card" style="margin-top:1%">
		    <form action="register.php" method="post">
				<h2 style="text-align:center; font-weight: 300; font-size: 2.3em;">Register</h2><br>
		    	<div class="form-group">
						<input type="text" class="form-control" name="fullname" placeholder="Full Name" required="required">
		      </div>

		      <div class="form-group">
		        <input type="email" class="form-control" name="email" placeholder="Email" required="required">
		      </div>

					<div class="form-group">
		      	<input type="tel" class="form-control" name="phone" placeholder="Phone Number" max=10 pattern="^[+]?[01]?[- .]?(\([2-9]\d{2}\)|[2-9]\d{2})[- .]?\d{3}[- .]?\d{4}$" required="required">
		      </div>

					<div class="form-group">
				  	<input type="date" name="dob" id="dob" class="form-control" max="2017-12-31" max="1900-01-01" required="required">
					</div>

					<div class="form-group">
						<select name="gender" id="gender" class="form-control" required="required" style="color:grey">
							<option> Select Gender</option>
							<option>Male</option>
							<option>Female</option>
							<option>Other</option>
						</select>
					</div>

					<div class="form-group">
						<input id="street_number" name="street" placeholder="Street" rows="3" class="form-control" />
					</div>
					<div class="form-group">
						<input id="route" name="address" placeholder="Route" rows="3" class="form-control" />
					</div>
					<div class="form-group">
						<input type="text" id="sublocality_level_1" name="city" placeholder="City" class="form-control">
					</div>
					<div class="row">
						<div class="col-sm-6 form-group">
							<input type="text" id="administrative_area_level_1" name="state" placeholder="State" class="form-control">
						</div>
						<div class="col-sm-6 form-group">
							<input type="text"  id="postal_code" name="postalcode" placeholder="Postal Code" max=6 class="form-control">
						</div>
					</div>

					<div class="form-group">
				  	<input type="password" class="form-control" min=4 max=8 name="password" placeholder="Password" required="required">
				  </div>

					<div class="form-group">
		      	<input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password" required="required">
		      </div>

					<div class="form-group">
		      	<button type="submit" class="btn btn-success btn-lg btn-block" name="register">Register Now</button>
		      </div>
		    </form>
			<div class="text-center">Already have an account? <a href="login.php">Sign in</a></div>

</div>
<footer class="py-4 bg-dark" style="margin-top:2%">
	<div class="container">
		<p class="m-0 text-center text-white">Copyright &copy; Business To Consumer 2018</p>
	</div>
	<!-- /.container -->
</footer>


<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCuk2WpGVbhkarHqpDIEi1PSjPXRPW_y08&libraries=places"></script>
<script type="text/javascript">
var autocomplete;
var componentForm = {
				street_number:'short_name',
        route: 'long_name',
        sublocality_level_1: 'long_name',
				administrative_area_level_1: 'long_name',
        postal_code: 'short_name'
      };

function initialize() {
    var input = document.getElementById('street_number');
    var options = {componentRestrictions: {country: 'ca'}};

    autocomplete = new google.maps.places.Autocomplete(input, options);

		autocomplete.addListener('place_changed', fillInAddress);
}

google.maps.event.addDomListener(window, 'load', initialize);

function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
					console.log(addressType);
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }
</script>

	<?php
	// REGISTER USER
	if (isset($_POST["register"])) {
		// echo "Inside";

		// initializing variables
		$errors = array();

	  // receive all input values from the form
	  $fullname = $_POST['fullname'];
	  $email = $_POST['email'];
		$phone = $_POST['phone'];
		$dob = $_POST['dob'];
		$gender = $_POST['gender'];
		$street = $_POST['street'];
		$address = $_POST['address'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$postalcode = $_POST['postalcode'];
	  $password_1 = $_POST['password'];
	  $password_2 = $_POST['confirm_password'];

		// echo "Name: " .$fullname;
		// echo $email;
		// echo $phone;
		// echo $dob;
		// echo $gender;
		// echo $address;
		// echo $city;
		// echo $state;
		// echo $postalcode;
		// echo $password_1;
		// echo $password_2;

		// connect to the database
		// $con = mysql_connect('localhost','root','') or die(mysql_error());
		// mysql_select_db('B2C') or die("cannot select DB");

	  // form validation: ensure that the form is correctly filled ...
	  // by adding (array_push()) corresponding error unto $errors array
	  if (empty($fullname)) { array_push($errors, "Username is required"); }
	  if (empty($email)) { array_push($errors, "Email is required"); }
	  if (empty($password_1)) { array_push($errors, "Password is required"); }
	  if ($password_1 != $password_2) {
		array_push($errors, "The two passwords do not match");
	  }

	  // first check the database to make sure
	  // a user does not already exist with the same username and/or email
	  $user_check_query = mysql_query("SELECT * FROM User WHERE Email='$email' LIMIT 1");
		$numrows = mysql_num_rows($user_check_query);
	  // $user = mysql_fetch_assoc($user_check_query);

	  if ($numrows != 0) { // if user exists
			echo "more row exists";
			while($user = mysql_fetch_assoc($user_check_query)){
		    if ($user['Email'] === $email) {
		      array_push($errors, "Email already exists");
					$message = '<span style = "color:red; margin-left:30%; font-weight:bold">Email already Exists!</span>';
					echo $message;
		    }
			}
	  }

	  // Finally, register user if there are no errors in the form
		// echo "Errors " .count($errors);
		// print_r($errors);
	  if (count($errors) == 0) {
	  	$password = md5($password_1);//encrypt the password before saving in the database
			// echo $password;

	  	$query = "INSERT INTO User (FullName, Email, Phone, DOB, Gender, Street, Address, City, State, PostalCode, Password)
	  			  VALUES('$fullname', '$email', '$phone', '$dob', '$gender', '$street', '$address', '$city', '$state', '$postalcode', '$password')";
						if(mysql_query($query)){
						    // echo "Records added successfully.";
								$message = '<span style = "color:green; margin-left:30%; margin-top:20%; font-weight:bold">Registration Successfull</span>';
								echo $message;
						} else{
						    echo "ERROR: Could not able to execute $query. " . mysql_error($con);
				}
	  }
	}
	?>

<?php include("footer.php"); ?>
