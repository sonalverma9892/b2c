<?php include("header.php");
		include("dbconnect.php");
	header("Cache-Control: no cache");
	session_cache_limiter("private_no_expire");
	// $con = mysql_connect('localhost','root','') or die(mysql_error());
	// mysql_select_db('B2C') or die("cannot select DB");
	$qua =0;

	function updateQuantity(){
		if(isset($_SESSION["cart_item"])){
	  	$cart_count = $_SESSION["qua"];
	  }else{
	    $cart_count = 0;
	  }
		if (isset($_SESSION['sess_user'])): ?>
	  	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
				<div class="container">
					<a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse" id="navbarNavDropdown">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item">
								<a class="nav-link" href="#">Hello, <?php echo $_SESSION['userfullname'] ?></a>
							</li>
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									My Account
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
									<a class="dropdown-item" href="purchaseHistory.php">My Orders</a>
									<a class="dropdown-item" href="support.php">Contact Support</a>
									<a class="dropdown-item" href="logout.php">Logout</a>
								</div>
							</li>
							<li class="nav-item">
								<a href="cart.php">
									<img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
									<asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
								</li>
							</ul>
						</div>
					</div>
	  	</nav>
		<?php else: ?>
	  	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
	    	<div class="container">
	      	<a class="navbar-brand" href="index.php">B2C - Business to Consumer</a>
	      	<div class="collapse navbar-collapse" id="navbarResponsive">
	        	<ul class="navbar-nav ml-auto">
	          	<li class="nav-item">
	            	<a class="nav-link" href="login.php">Login</a>
	          	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="register.php">Register</a>
	          	</li>
							<li class="nav-item">
                <a class="nav-link" href="support.php">Contact Support</a>
              </li>
	          	<li class="nav-item">
	            	<a href="cart.php">
	            	<img vspace="6" src="https://a7.wal.co/assets/img/simplified-header/08c651011eb68321bfeb9019695d43a4-shopping-cart-icon.svg-7e3093e56901e462ce583b5aac30ca69c9591642" id="shopping-cart-icon" width="30" height="25">
	            	<asp:Label ID="lblCartCount" runat="server" CssClass="badge badge-warning"  ForeColor="White"/><?php echo $cart_count; ?></a>
	          	</li>
	        	</ul>
	      	</div>
	    	</div>
	  	</nav>
		<?php endif;
	}

	if(isset($_POST["type"]) && $_POST["type"]=='add'){
		if(!empty($_POST["quantity"])) {
			$productByCode = mysql_query("SELECT * FROM tblproduct WHERE code='" .$_POST["product_code"]. "'");
			while($row=mysql_fetch_assoc($productByCode)) {
				$resultset[] = $row;
			}
			$itemArray = array($resultset[0]["code"]=>array('name'=>$resultset[0]["name"], 'code'=>$resultset[0]["code"], 'quantity'=>$_POST["quantity"], 'price'=>$resultset[0]["price"]));
			// echo "itemarray " .print_r($itemArray);
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($resultset[0]["code"],array_keys($_SESSION["cart_item"]))) {
					// print_r($_SESSION["cart_item"]);
					foreach($_SESSION["cart_item"] as $k => $v) {
						// echo $k;
							if($resultset[0]["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	}

	if(!empty($_GET["action"])) {
		if($_GET["action"]=='remove'){
			if(!empty($_SESSION["cart_item"])) {
				foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
						$_SESSION["qua"] = 0;
						updateQuantity();
				}
			}
		}
	}

	if(isset($_POST["empty"])){
		// print_r($_SESSION["cart_item"]);
		unset($_SESSION["cart_item"]);
		$_SESSION["qua"] = 0;
		updateQuantity();
	}

?>

<div class="container">
	<form method="post">
	<div class="h2 nav-link" style="margin-top:10%; background-color:#343a40; color:#AEB6BF; margin-bottom:0%; font-size:24px">Your Shopping Cart<span style="margin-left:65%"><?php if(!isset($_POST["empty"]) && isset($_SESSION["cart_item"])){foreach($_SESSION["cart_item"] as $k => $v){$qua += $_SESSION["cart_item"]["$k"]["quantity"]; } $_SESSION["qua"] = $qua; echo $qua;} else{$qua = 0;}?> Items</span></div>

<?php
updateQuantity();
if(isset($_SESSION["cart_item"])){
	// $cart_count = count($_SESSION["cart_item"]);
		// print_r($_SESSION["cart_item"]);
    $item_total = 0;
		$currency = '&#36;';
		$shipping_cost      = 5.50; //shipping cost
		$taxes              = 3 //List your Taxes percent here.

?>
<table class="table table-striped" style="align:center">
<tbody>
<tr style="background-color:#5DADE2  ">
<th style="text-align:center;"><strong>Name</strong></th>
<th style="text-align:center"><strong>Code</strong></th>
<th style="text-align:center"><strong>Quantity</strong></th>
<th style="text-align:center"><strong>Price</strong></th>
<th style="text-align:center"><strong>Action</strong></th>
</tr>
	<?php
    foreach ($_SESSION["cart_item"] as $item){
	?>
				<tr>
				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><strong><?php echo $item["name"]; ?></strong></td>
				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo $item["code"]; ?></td>
				<!-- <input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" /> -->
				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><input disabled type="number" size="2" min="1" max="50" maxlength="2" name="cartQuantity" value="<?php echo $item["quantity"]?>" />
				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><?php echo "$".$item["price"]*$item["quantity"]; ?></td>
				<td style="text-align:center;border-bottom:#F0F0F0 1px solid;"><a  href="cart.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction">Remove Item</a></td>
				</tr>
				<?php
        $item_total += ($item["price"]*$item["quantity"]);
		}

		$grand_total = $item_total + $shipping_cost; //grand total including shipping cost
		// echo "grand " .$grand_total;
		//list and calculate all taxes in array
		$tax_amount     = round($item_total * ($taxes / 100));
		// echo $tax_amount. "<br>";
		$grand_total    = $grand_total + $tax_amount;  //add tax val to grand total

		// echo "grand " .$grand_total;
		// print_r($tax_item);
		$list_tax ='HST : '. $currency. sprintf("%01.2f", $tax_amount).'<br />';
		$shipping_cost = ($shipping_cost)?'B2C Shipping : '.$currency. sprintf("%01.2f", $shipping_cost).'<br />':'';
		?>

<tr>
<td colspan="5" align=right><strong>Subtotal:</strong> <?php echo "$".$item_total; ?></td></tr>
<tr><td colspan="5" align=right><span style="float:right;text-align: right; "><?php echo $shipping_cost. $list_tax; ?>Estimated Total : <?php echo sprintf("%01.2f", $grand_total);?></span></td></tr>

</tbody>
</table>
<button style="padding: 10px 60px;"class="btn btn-primary" type="submit" name="empty">Empty Cart</button>
<button class="btn btn-primary"  style="margin-left:22%; padding: 10px 40px;"><a href="index.php" style="color:white">Continue Shopping</a></button>
<button class="btn btn-primary" style="margin-left:21%; padding: 10px 60px;" ><a href="map.php" style="color:white">Checkout</a></button>
</form>
  <?php
}else{
	echo '<div style ="color:red; margin-left:46%; font-weight:bold; margin-top:12%; font-size:24px">Cart Empty!</div><br>';
	echo '<button class="btn btn-primary" style="margin-top:12%; padding: 10px 100px;"><a href="index.php" style="color:white;  ">Back</a></button>';
}
?>

<?php include("footer.php");?>
